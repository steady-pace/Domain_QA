package com.qa.util;



import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
//import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;

public class DownHtml{
	
	
	
	//������wrapClient����
	/**
	* ��ȡ������https���ӣ��Ա��ⲻ������֤�����peer not authenticated�쳣
	*
	* @param base
	* @return
	*/
	public static HttpClient wrapClient(HttpClient base) {
	try {
	SSLContext ctx = SSLContext.getInstance("TLS");
	X509TrustManager tm = new X509TrustManager() {
	public void checkClientTrusted(X509Certificate[] xcs,
	String string) {
	}
	public void checkServerTrusted(X509Certificate[] xcs,
	String string) {
	}
	public X509Certificate[] getAcceptedIssuers() {
	return null;
	}
	};
	ctx.init(null, new TrustManager[] { tm }, null);
	SSLSocketFactory ssf = new SSLSocketFactory(ctx);
	ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	ClientConnectionManager ccm = base.getConnectionManager();
	SchemeRegistry sr = ccm.getSchemeRegistry();
	sr.register(new Scheme("https", ssf, 443));
	return new DefaultHttpClient(ccm, base.getParams());
	} catch (Exception ex) {
	ex.printStackTrace();
	return null;
	}
	}
	
	public static String gethtml(String url_str)
	{   //String filepath = "d:/��ʳ����2.html";
		
		//connection.setRequestProperty("User-Agent", this.userAgent)
		String html_str="";
		String charset = "utf-8";//"utf-8";
		
		
		//HttpClient client = new DefaultHttpClient();  
	  // HttpClient hc = wrapClient(client);  
		HttpClient hc = new DefaultHttpClient();
		
		//hc = wrapClient(hc);
		
		
		
		
		
		
		
		
		HttpParams header = hc.getParams();  
        System.out.println(header);
        
        HttpGet hg = new HttpGet(url_str);
        HttpResponse response = null;
		try {
			response = hc.execute(hg);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        HttpEntity entity = response.getEntity();
        if(entity != null){
            System.out.println(entity.getContentLength());
            InputStream htm_in = null;
			try {
				htm_in = entity.getContent();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            try {
				html_str = InputStream2String(htm_in,charset);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
			//saveHtml(filepath,htm_str);
        }
		
		
		return html_str;
		
	}

	
	//��ο����������Ƶ��
	//��ζ��IP,���з��ʷ�����?ʹ�ô�������������������������
	//�����������ǲ���
	//http://www.open-open.com/lib/view/open1427353292652.html
	
	public static void work(String name)
	{
		File file =new File("D:/�ѹ�����/"+name);    
		//����ļ��в������򴴽�    
		if  (!file .exists()  && !file .isDirectory())      
		{       
		    System.out.println("//������,���ڽ����ļ���");  
		    file .mkdir();    
		} else   
		{  
		    System.out.println("//Ŀ¼����");  
		}  
		
		String url_str ="";// "http://www.meishichina.com/Health/CommonSense";//"http://www.hao123.com";
        //String charset = "gb2312";//"utf-8";
        int i=0;
       
       
       // System.out.println(htm_str);
        for(i=0;i<21;i++)
        {
        	url_str="http://wenwen.sogou.com/s?w="+name+"&pg="+i+"&ch=sp.pt";//"http://www.meishichina.com/Health/CommonSense/List_"+i+".html";//"http://www.meishichina.com/Health/CommonSense";
        	String filepath="D:/�ѹ�����/"+name+"/"+i+".html";//"d:/��ʳ����3.html";
        	System.out.println(filepath);
        	
        	try {
   				Thread.sleep(2000);
   			} catch (InterruptedException e) {
   				// TODO Auto-generated catch block
   				e.printStackTrace();
   			}
   		    System.out.print(" �߳�˯��2�룡\n");
        	
        	
        	String htm_str=gethtml(url_str);
        	System.out.println(htm_str.length());
        	
        	//�������С��ĳ��ֵ
        	//ɾ���ļ�,��������
        	int count=0;
        	while(htm_str.length()<10000&count<10)  //��ֹ���صĲ���ȫ��ҳ��
        	{
        		//for(int j=0;i<1000;j++)
        		//{}
        		System.out.println(htm_str.length());
        		//ɾ��ָ���ļ�����������
        		
        		File file2 =new File(filepath);
        		file2.delete();
        		htm_str=gethtml(url_str);
        		count++;
        		
        		
        		try {
       				Thread.sleep(2000);
       			} catch (InterruptedException e) {
       				// TODO Auto-generated catch block
       				e.printStackTrace();
       			}
       		    System.out.print(" �߳�˯��2�룡\n");
        		
        		//else
        			//htm_str=gethtml(url_str);
        			
        			
        		
        	}
        	
        	
        	
        	
        	
    		saveHtml(filepath,htm_str);
    		
        }
        
      
        
       
		
	}
	
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        work("����");
    }
   
    
    
    /**
     * Method: saveHtml 
     * Description: save String to file
     * @param filepath
     * file path which need to be saved
     * @param str
     * string saved
     */
    public static void saveHtml(String filepath, String str){
        
        try {
            /*@SuppressWarnings("resource")
            FileWriter fw = new FileWriter(filepath);
            fw.write(str);
            fw.flush();*/
            OutputStreamWriter outs = new OutputStreamWriter(new FileOutputStream(filepath, true), "utf8");
            outs.write(str);
            outs.close();
        } catch (IOException e) {
            System.out.println("Error at save html...");
            e.printStackTrace();
        }
    }
    
    /**
     * Method: InputStream2String 
     * Description: make InputStream to String
     * @param in_st
     * inputstream which need to be converted
     * @param charset
     * encoder of value
     * @throws IOException
     * if an error occurred 
     */
    public static String InputStream2String(InputStream in_st,String charset) throws IOException{
        BufferedReader buff = new BufferedReader(new InputStreamReader(in_st, charset));
        StringBuffer res = new StringBuffer();
        String line = "";
        while((line = buff.readLine()) != null){
            res.append(line);
        }
        return res.toString();
    }
}