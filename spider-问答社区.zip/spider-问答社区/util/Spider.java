package com.qa.util;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class Spider{
	
	public static String gethtml(String url_str)
	{   //String filepath = "d:/��ʳ����2.html";
		String html_str="";
		String charset = "utf-8";//"utf-8";
		HttpClient hc = new DefaultHttpClient();
        HttpGet hg = new HttpGet(url_str);
        HttpResponse response = null;
		try {
			response = hc.execute(hg);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        HttpEntity entity = response.getEntity();
        if(entity != null){
            System.out.println(entity.getContentLength());
            InputStream htm_in = null;
			try {
				htm_in = entity.getContent();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            try {
				html_str = InputStream2String(htm_in,charset);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
			//saveHtml(filepath,htm_str);
        }
		
		
		return html_str;
		
	}

	
	public static void work(String name)
	{
		File file =new File("D:/�ѹ�����/"+name);    
		//����ļ��в������򴴽�    
		if  (!file .exists()  && !file .isDirectory())      
		{       
		    System.out.println("//������,���ڽ����ļ���");  
		    file .mkdir();    
		} else   
		{  
		    System.out.println("//Ŀ¼����");  
		}  
		
		String url_str ="";// "http://www.meishichina.com/Health/CommonSense";//"http://www.hao123.com";
        //String charset = "gb2312";//"utf-8";
        int i=0;
       
       
       // System.out.println(htm_str);
        for(i=0;i<51;i++)
        {
        	url_str="http://wenwen.sogou.com/s?w="+name+"&pg="+i+"&ch=sp.pt";//"http://www.meishichina.com/Health/CommonSense/List_"+i+".html";//"http://www.meishichina.com/Health/CommonSense";
        	String filepath="D:/�ѹ�����/"+name+"/"+i+".txt";//"d:/��ʳ����3.html";
        	System.out.println(filepath);
        	String htm_str=gethtml(url_str);
    		saveHtml(filepath,htm_str);
        }
        
        
       
		
	}
    public static void main(String[] args) throws Exception {
        // TODO Auto-generated method stub
        work("�ղ�");
    }
    /**
     * Method: saveHtml 
     * Description: save String to file
     * @param filepath
     * file path which need to be saved
     * @param str
     * string saved
     */
    public static void saveHtml(String filepath, String str){
        
        try {
            /*@SuppressWarnings("resource")
            FileWriter fw = new FileWriter(filepath);
            fw.write(str);
            fw.flush();*/
            OutputStreamWriter outs = new OutputStreamWriter(new FileOutputStream(filepath, true), "utf-8");
            outs.write(str);
            outs.close();
        } catch (IOException e) {
            System.out.println("Error at save html...");
            e.printStackTrace();
        }
    }
    /**
     * Method: InputStream2String 
     * Description: make InputStream to String
     * @param in_st
     * inputstream which need to be converted
     * @param charset
     * encoder of value
     * @throws IOException
     * if an error occurred 
     */
    public static String InputStream2String(InputStream in_st,String charset) throws IOException{
        BufferedReader buff = new BufferedReader(new InputStreamReader(in_st, charset));
        StringBuffer res = new StringBuffer();
        String line = "";
        while((line = buff.readLine()) != null){
            res.append(line);
        }
        return res.toString();
    }
}